'use client';

import Link from 'next/link';
import {
  marketingByGroup,
  marketingGroupLabels,
  marketingServices,
  type MarketingGroup,
} from '@/lib/services';
import styles from './MegaMenu.module.css';

type Props = { open: boolean };

const groupOrder: MarketingGroup[] = ['seo', 'paid', 'social', 'analytics'];

export default function MarketingMegaMenu({ open }: Props) {
  const total = marketingServices().length;

  return (
    <div className={`${styles.megaWrap} ${styles.megaWrapWide} ${open ? styles.megaWrapOpen : ''}`}>
      <div className={styles.megaPanel}>
        <div className={`${styles.megaGrid} ${styles.megaGrid4}`}>
          {groupOrder.map((group) => {
            const items = marketingByGroup(group);
            if (items.length === 0) return null;
            const meta = marketingGroupLabels[group];
            return (
              <div key={group} className={styles.megaColumn}>
                <div className={styles.colHeader}>
                  <span className={styles.colNum}>{meta.num}</span>
                  <span className={styles.colLabel}>{meta.label}</span>
                </div>
                <p className={styles.colSubtitle}>{meta.description}</p>
                <ul className={styles.serviceList}>
                  {items.map((s) => {
                    const Icon = s.icon;
                    return (
                      <li key={s.slug}>
                        <Link href={`/services/${s.slug}`} className={styles.serviceLink}>
                          <span className={styles.serviceIconBox}>
                            <Icon size={14} strokeWidth={1.6} />
                          </span>
                          <span className={styles.serviceText}>
                            <span className={styles.serviceTitle}>{s.shortTitle}</span>
                            <span className={styles.serviceDesc}>{s.tagline}</span>
                          </span>
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </div>

        <div className={styles.bottomStrip}>
          <span className={styles.stripText}>
            {total} SEO &amp; marketing services · Strategy · Execution · Reporting
          </span>
          <Link href="/digital-marketing" className={styles.stripLink}>
            View all marketing services →
          </Link>
        </div>
      </div>
    </div>
  );
}
